﻿from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import StaticPool

Base = declarative_base()

class DatabaseManager:
    def __init__(self, host='localhost', database='network_monitor', 
                 user='postgres', password='amogus', port=5432):
        self.connection_string = f"postgresql://{user}:{password}@{host}:{port}/{database}"
        self.engine = None
        self.SessionLocal = None
        self.current_session = None
    
    def connect(self):
        try:
            self.engine = create_engine(
                self.connection_string,
                poolclass=StaticPool,
                echo=False
            )
            self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
            self.current_session = self.SessionLocal()
         
            with self.engine.connect() as conn:
                pass
                
            return True, "Успешное подключение к базе данных"
        except Exception as e:
            return False, f"Ошибка подключения: {e}"
    
    def disconnect(self):
        if self.current_session:
            self.current_session.close()
        if self.engine:
            self.engine.dispose()
    
    def create_tables(self):
        try:
            Base.metadata.create_all(bind=self.engine)
            return True, "Таблицы успешно созданы"
        except Exception as e:
            return False, f"Ошибка создания таблиц: {e}"
    
    def drop_tables(self):
        try:
            Base.metadata.drop_all(bind=self.engine)
            return True, "Таблицы успешно удалены"
        except Exception as e:
            return False, f"Ошибка удаления таблиц: {e}"
    
    def get_session(self):
        if not self.current_session:
            self.connect()
        return self.current_session